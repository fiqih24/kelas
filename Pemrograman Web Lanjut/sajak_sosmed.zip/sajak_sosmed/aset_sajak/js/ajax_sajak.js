function sjk_hapus_pesan(id) {
	if (confirm('Anda yakin menghapus pesan ini ?')) {
		$.ajax({
			type: "GET",
			url: base_url+"index.php/sajak/delete_pesan/"+id,
			success: function(response) {
				if (response.status == "oke") {
					window.location.assign(base_url+"index.php/sajak/page/pesan");
				} else {
					console.log('gagal');
				}
			}
		});
	}
	return false;
}

function sjk_hapus_status(id_status){
	if(confirm('anda yakin menghapus status ini ?')){
		$.ajax({
			type: "GET",
			url: base_url+"index.php/sajak/delete_my_status/"+id_status,
			success: function (response) {
				if(response.status == "oke" ){
					window.location.assign(base_url+"index.php/sajak/page/my_profile");
				}else{
					console.log('gagal');
				}
			}
		});
	}
return false;
}

function sjk_hapus_sajak(idsjk) {
	if (confirm('Anda yakin menghapus sajak ini ?')) {
		$.ajax({
			type: "GET",
			url: base_url+"index.php/sajak/delete_sajak/"+idsjk,
			success: function(response) {
				if (response.status == "oke") {
					window.location.assign(base_url+"index.php/sajak/page/buat_sajak");
				} else {
					console.log('gagal');
				}
			}
		});
	}
	return false;
}

function tutup_sajak(id_sjk) {
	if (confirm('Anda ingin menonaktifkan Sajak Ini ?')) {
		$.ajax({
			type: "GET",
			url: base_url+"index.php/sajak/tutup_sajak/"+id_sjk,
			success: function(response) {
				if (response.status == "oke") {
					window.location.assign(base_url+"index.php/sajak/page/buat_sajak");
				} else {
					console.log('gagal');
				}
			}
		});
	}
	return false;
}
